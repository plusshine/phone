# Guazi
瓜子二手车直卖网https://www.guazi.com/ 的爬虫

网站有反扒，请求过快会封ip，不得已采用了ip代理。渣机渣网跑了6个小时，爬10w条数据。数据包含线上展示的二手车的部分信息，抓的数据存入本地mysql数据库。
数据截止时间3月10号

![pic](https://github.com/malone6/Guazi/blob/master/data_pic.jpg)

## 用echarts做简单的数据可视化

![pic](https://github.com/malone6/Guazi/blob/master/echart%E6%BC%94%E7%A4%BA/car_brand_pie.jpg)
![pic](https://github.com/malone6/Guazi/blob/master/echart%E6%BC%94%E7%A4%BA/car_sec_price.jpg)
![pic](https://github.com/malone6/Guazi/blob/master/echart%E6%BC%94%E7%A4%BA/car_map.jpg)
